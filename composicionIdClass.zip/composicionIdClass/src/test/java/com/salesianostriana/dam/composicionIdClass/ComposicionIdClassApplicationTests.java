package com.salesianostriana.dam.composicionIdClass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComposicionIdClassApplicationTests {

	@Test
	void contextLoads() {
	}

}
