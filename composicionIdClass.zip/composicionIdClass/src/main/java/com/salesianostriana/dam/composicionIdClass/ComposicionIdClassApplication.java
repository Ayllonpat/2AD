package com.salesianostriana.dam.composicionIdClass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComposicionIdClassApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComposicionIdClassApplication.class, args);
	}

}
