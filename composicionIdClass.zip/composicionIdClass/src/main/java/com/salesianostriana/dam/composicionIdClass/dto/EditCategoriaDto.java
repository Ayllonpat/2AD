package com.salesianostriana.dam.composicionIdClass.dto;

public record EditCategoriaDto(
        String nombre,
        Long idCategoria
) {
}
