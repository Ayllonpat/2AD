package com.salesianostriana.dam.modelodatos_ejercicio3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModelodatosEjercicio3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
