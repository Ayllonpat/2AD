package com.salesianostriana.dam.modelodatos_ejercicio3.repository;

import com.salesianostriana.dam.modelodatos_ejercicio3.model.Uso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsoRepository extends JpaRepository<Uso, Long> {
}
